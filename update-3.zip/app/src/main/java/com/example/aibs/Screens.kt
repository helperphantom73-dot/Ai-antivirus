package com.example.aibs

import android.content.Context
import android.os.PowerManager
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val BG = Color(0xFF070A12)
val PANEL = Color(0xFF101623)
val CYAN = Color(0xFF00E5FF)
val VIOLET = Color(0xFF7C4DFF)
val GREEN = Color(0xFF00E676)
val AMBER = Color(0xFFFFB300)
val RED = Color(0xFFFF5252)
val TEXT = Color(0xFFE6EDF7)
val MUTED = Color(0xFF8A97AD)

fun Level.color() = when (this) {
    Level.SAFE -> GREEN
    Level.WATCH -> CYAN
    Level.MEDIUM -> AMBER
    Level.HIGH -> RED
}

fun sevColor(s: Sev) = when (s) {
    Sev.GOOD -> GREEN
    Sev.INFO -> CYAN
    Sev.WARN -> AMBER
    Sev.BAD -> RED
}

fun scoreColor(s: Int) = if (s >= 80) GREEN else if (s >= 55) AMBER else RED
fun scoreLabel(s: Int) = if (s >= 80) "ایمن" else if (s >= 55) "نیازمند توجه" else "در خطر"
fun thermalLabel(t: Int) = when (t) {
    0 -> "عادی"; 1 -> "سبک"; 2 -> "متوسط"; 3 -> "شدید"; 4 -> "بحرانی"; 5 -> "اضطراری"; else -> "خاموشی"
}

@Composable
fun AibsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = CYAN, onPrimary = BG, secondary = VIOLET,
            background = BG, surface = PANEL, onBackground = TEXT, onSurface = TEXT
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { content() }
    }
}

@Composable
fun screenPad(): PaddingValues {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    return PaddingValues(start = 16.dp, end = 16.dp, top = top + 12.dp, bottom = 140.dp)
}

// ---------- app shell ----------

@Composable
fun AibsApp() {
    val st by Hub.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize()) {
        AuroraBackground()
        AnimatedContent(
            targetState = tab,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally(spring(0.85f, 260f)) { (it * 0.12f * dir).toInt() } +
                    fadeIn(tween(280, 60)) + scaleIn(tween(360), 0.96f)) togetherWith
                    (fadeOut(tween(140)) + scaleOut(tween(200), 0.98f))
            },
            label = "tabs"
        ) { t ->
            when (t) {
                0 -> HomeScreen(st) { tab = it }
                1 -> AssistantScreen(st) { tab = it }
                2 -> AppsScreen(st)
                3 -> OptimizerScreen(st) { tab = it }
                else -> MoreScreen(st)
            }
        }
        FloatingNav(
            tab, { tab = it },
            listOf("خانه" to Icons.Filled.Home, "دستیار" to Icons.Filled.Face, "برنامه‌ها" to Icons.Filled.Search,
                "بهینه‌ساز" to Icons.Filled.Build, "بیشتر" to Icons.Filled.Menu),
            Modifier.align(Alignment.BottomCenter)
        )
    }
}

@Composable
fun FloatingNav(tab: Int, onTab: (Int) -> Unit, items: List<Pair<String, ImageVector>>, modifier: Modifier = Modifier) {
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(28.dp)
    BoxWithConstraints(
        modifier.navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp)
            .fillMaxWidth().height(68.dp).clip(shape)
            .background(Color(0xE6101623)).border(1.dp, Color(0x2AFFFFFF), shape)
    ) {
        val itemW = maxWidth / items.size
        val x by animateDpAsState(itemW * tab, spring(dampingRatio = 0.62f, stiffness = 380f), label = "indicator")
        Box(
            Modifier.offset(x = x).width(itemW).fillMaxHeight().padding(8.dp)
                .clip(RoundedCornerShape(20.dp)).background(CYAN.copy(alpha = 0.16f))
        )
        Row(Modifier.fillMaxSize()) {
            items.forEachIndexed { i, (label, icon) ->
                val sel = tab == i
                val sc by animateFloatAsState(if (sel) 1.18f else 1f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "navScale")
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable(
                        interactionSource = remember { MutableInteractionSource() }, indication = null
                    ) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onTab(i)
                    },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(icon, null, tint = if (sel) CYAN else MUTED,
                        modifier = Modifier.size(22.dp).graphicsLayer { scaleX = sc; scaleY = sc })
                    Text(label, fontSize = 10.sp, color = if (sel) CYAN else MUTED)
                }
            }
        }
    }
}

@Composable
fun SegControl(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    BoxWithConstraints(Modifier.fillMaxWidth().height(44.dp).clip(shape).background(Color(0xB8101623)).border(1.dp, Color(0x22FFFFFF), shape)) {
        val w = maxWidth / options.size
        val x by animateDpAsState(w * selected, spring(dampingRatio = 0.7f, stiffness = 400f), label = "seg")
        Box(Modifier.offset(x = x).width(w).fillMaxHeight().padding(4.dp).clip(RoundedCornerShape(12.dp)).background(CYAN.copy(alpha = 0.2f)))
        Row(Modifier.fillMaxSize()) {
            options.forEachIndexed { i, t ->
                Box(
                    Modifier.weight(1f).fillMaxHeight().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) { Text(t, color = if (i == selected) CYAN else MUTED, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) }
            }
        }
    }
}

// ---------- shared pieces ----------

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier.fillMaxWidth().clip(shape)
            .background(Color(0xB8101623))
            .background(Brush.verticalGradient(listOf(Color(0x1FFFFFFF), Color(0x08FFFFFF))))
            .border(1.dp, Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x10FFFFFF))), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp), content = content
    )
}

@Composable
fun InsightRow(i: Insight, onTab: (Int) -> Unit) {
    val c = LocalContext.current
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Box(Modifier.width(4.dp).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(sevColor(i.sev)))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(i.title, color = TEXT, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(i.body, color = MUTED, fontSize = 12.sp)
            i.act?.let { a ->
                Text(
                    a.label, color = CYAN, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.bounceClick { runAct(c, a, onTab) }.padding(vertical = 4.dp)
                )
            }
        }
    }
}

// ---------- apps ----------

@Composable
fun AppCard(a: AppRisk, modifier: Modifier = Modifier) {
    val c = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Panel(modifier.animateContentSize(spring(dampingRatio = 0.8f, stiffness = 300f)).bounceClick { open = !open }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(a.label, color = TEXT, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(a.pkg, color = MUTED, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(a.level.color().copy(alpha = 0.18f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) { Text("${a.level.fa} · ${a.score}".fa(), color = a.level.color(), fontSize = 12.sp) }
        }
        AnimatedVisibility(open) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (a.reasons.isEmpty()) Text("مورد قابل‌توجهی پیدا نشد.", color = MUTED, fontSize = 12.sp)
                a.reasons.forEach { Text("• $it", color = TEXT, fontSize = 12.sp) }
                Text(
                    "ارسال ${"%.1f".format(Locale.US, a.txMb)} MB · دریافت ${"%.1f".format(Locale.US, a.rxMb)} MB · پیش‌زمینه ${a.fgMin} دقیقه (۱ ساعت اخیر)".fa(),
                    color = MUTED, fontSize = 11.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlowButton("توقف اجباری", Modifier.weight(1f), filled = false) { openAppSettings(c, a.pkg) }
                    GlowButton("حذف", Modifier.weight(1f), filled = false) { uninstallApp(c, a.pkg) }
                    GlowButton(if (a.trusted) "لغو اعتماد" else "اعتماد", Modifier.weight(1f), filled = false) { Hub.toggleTrust(c, a.pkg) }
                }
            }
        }
    }
}

@Composable
fun AppsScreen(st: UiState) {
    var onlyRisky by remember { mutableStateOf(true) }
    val list = if (onlyRisky) st.apps.filter { it.level != Level.SAFE } else st.apps
    LazyColumn(Modifier.fillMaxSize(), contentPadding = screenPad(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("برنامه‌ها (${st.apps.size})".fa(), color = TEXT, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                FilterChip(selected = onlyRisky, onClick = { onlyRisky = !onlyRisky }, label = { Text("فقط مشکوک‌ها") })
            }
        }
        if (list.isEmpty()) item { Panel { Text("موردی برای نمایش نیست ✓", color = MUTED) } }
        items(list, key = { it.pkg }) { AppCard(it) }
    }
}

// ---------- more: alerts + settings ----------

@Composable
fun MoreScreen(st: UiState) {
    val c = LocalContext.current
    var seg by remember { mutableIntStateOf(0) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = screenPad(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SegControl(listOf("هشدارها", "تنظیمات"), seg) { seg = it } }
        if (seg == 0) alertItems(st) else settingsItems(st, c)
    }
}

fun LazyListScope.alertItems(st: UiState) {
    item {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تاریخچهٔ هشدارها", color = TEXT, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            if (st.events.isNotEmpty()) TextButton({ Hub.clearEvents() }) { Text("پاک‌سازی") }
        }
    }
    if (st.events.isEmpty()) item { Panel { Text("هنوز هشداری ثبت نشده است.", color = MUTED) } }
    items(st.events) { e ->
        val fmt = SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault())
        Panel {
            Row {
                Text(e.label, color = TEXT, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${e.score}".fa(), color = if (e.score >= 70) RED else AMBER, fontWeight = FontWeight.Bold)
            }
            Text(fmt.format(Date(e.time)).fa(), color = MUTED, fontSize = 11.sp)
            Text(e.reason, color = TEXT, fontSize = 12.sp)
        }
    }
}

@Composable
fun PermRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = TEXT, fontSize = 14.sp)
                Text(if (ok) "فعال ✓" else "غیرفعال", color = if (ok) GREEN else AMBER, fontSize = 12.sp)
            }
            if (!ok) GlowButton(action, filled = false, onClick = onClick)
        }
    }
}

fun LazyListScope.settingsItems(st: UiState, c: Context) {
    item {
        val notif = NotificationManagerCompat.from(c).areNotificationsEnabled()
        val battery = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PermRow("دسترسی Usage (شبکه، پیش‌زمینه، عادت‌ها)", st.usageAccess, "فعال‌سازی") { openUsageAccess(c) }
            PermRow("معافیت از بهینه‌سازی باتری (پایداری سرویس)", battery, "درخواست") { openBatterySettings(c) }
            PermRow("اعلان‌ها", notif, "تنظیمات") { openAppSettings(c, c.packageName) }
        }
    }
    item {
        Panel {
            var on by remember { mutableStateOf(Store.briefing) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("گزارش صبحگاهی", color = TEXT, fontSize = 14.sp)
                    Text("هر روز حدود ساعت ۸، خلاصهٔ وضعیت گوشی در اعلان", color = MUTED, fontSize = 12.sp)
                }
                Switch(
                    checked = on,
                    onCheckedChange = {
                        on = it
                        Store.briefing = it
                        if (it) BriefingScheduler.schedule(c) else BriefingScheduler.cancel(c)
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = BG, checkedTrackColor = CYAN)
                )
            }
            GlowButton("ارسال گزارش آزمایشی", Modifier.fillMaxWidth(), filled = false) { BriefingScheduler.postNow(c) }
        }
    }
    item {
        Panel {
            Text("الگوریتم سلامت", color = CYAN, fontWeight = FontWeight.Bold)
            Text("سلامت = ۴۰٪ امنیت + ۱۵٪ رم + ۱۵٪ حافظه + ۱۵٪ باتری/دما + ۱۵٪ عادت‌های استفاده", color = TEXT, fontSize = 12.sp)
            Text("• امنیت: مجوزهای پرخطر، منبع نصب و مقایسهٔ ارسال شبکهٔ هر برنامه با تاریخچهٔ ۷ روزهٔ خودش (z-score)", color = MUTED, fontSize = 12.sp)
            Text("• دستیار یک سیستم قاعده‌محور و آماری است، نه مدل زبانی؛ همه‌چیز روی همین گوشی انجام می‌شود و هیچ داده‌ای ارسال نمی‌شود.", color = MUTED, fontSize = 12.sp)
            Text("• اندروید اجازهٔ بستن یا قرنطینهٔ برنامهٔ دیگر را نمی‌دهد؛ برنامه شما را به صفحهٔ توقف اجباری/حذف می‌برد.", color = MUTED, fontSize = 12.sp)
        }
    }
    item { Text("نسخه ۳٫۰ · ${st.apps.count { it.trusted }} برنامهٔ مورد اعتماد".fa(), color = MUTED, fontSize = 11.sp) }
}
