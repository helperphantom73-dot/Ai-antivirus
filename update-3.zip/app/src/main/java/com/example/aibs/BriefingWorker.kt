package com.example.aibs

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.Calendar
import java.util.concurrent.TimeUnit

class BriefingWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        val c = applicationContext
        Store.init(c)
        if (!Store.briefing) return Result.success()
        Hub.runScan(c)
        Hub.state.value.brief?.let { BriefingScheduler.post(c, it) }
        return Result.success()
    }
}

object BriefingScheduler {
    private const val CH = "briefing"

    fun schedule(c: Context) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 8); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val delay = cal.timeInMillis - System.currentTimeMillis()
        val req = PeriodicWorkRequestBuilder<BriefingWorker>(24, TimeUnit.HOURS)
            .setInitialDelay(delay, TimeUnit.MILLISECONDS).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("briefing", ExistingPeriodicWorkPolicy.UPDATE, req)
    }

    fun cancel(c: Context) {
        WorkManager.getInstance(c).cancelUniqueWork("briefing")
    }

    fun postNow(c: Context) {
        Hub.rebuildBrief(c)
        Hub.state.value.brief?.let { post(c, it) }
    }

    fun post(c: Context, b: Briefing) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "گزارش روزانه", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 3, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val lines = b.insights.filter { it.sev != Sev.GOOD }.take(4).joinToString("\n") { "• ${it.title}" }
            .ifEmpty { "موردی برای نگرانی نیست." }
        val n = NotificationCompat.Builder(c, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("گزارش گوشی · سلامت ${b.health}٪".fa())
            .setContentText(b.headline)
            .setStyle(NotificationCompat.BigTextStyle().bigText(b.summary + "\n" + lines))
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        nm.notify(9100, n)
    }
}
