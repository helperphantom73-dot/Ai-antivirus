package com.example.aibs

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

// ---------- modifiers ----------

/** Springy press feedback (scale-down on touch, overshoot on release). */
fun Modifier.bounceClick(onClick: () -> Unit): Modifier = composed {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = 0.42f, stiffness = 520f), label = "press")
    this.graphicsLayer { scaleX = s; scaleY = s }.clickable(interactionSource = src, indication = null, onClick = onClick)
}

/** Items rise, fade and scale in one after another (only the first few, so scrolling stays instant). */
fun Modifier.staggerIn(index: Int): Modifier =
    if (index >= 7) this else composed {
        val p = remember { Animatable(0f) }
        LaunchedEffect(Unit) {
            delay(index * 55L)
            p.animateTo(1f, spring(dampingRatio = 0.78f, stiffness = 170f))
        }
        graphicsLayer {
            val v = p.value
            alpha = v.coerceIn(0f, 1f)
            translationY = (1f - v) * 56f
            val sc = 0.95f + 0.05f * v
            scaleX = sc; scaleY = sc
        }
    }

/** Bouncy pop-in with overshoot. */
fun Modifier.popIn(delayMs: Long = 0L, from: Float = 0.8f): Modifier = composed {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs)
        p.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = 230f))
    }
    graphicsLayer {
        val sc = from + (1f - from) * p.value
        scaleX = sc; scaleY = sc
        alpha = p.value.coerceIn(0f, 1f)
    }
}

// ---------- aurora background ----------

@Composable
fun AuroraBackground() {
    val tr = rememberInfiniteTransition(label = "aurora")
    val a by tr.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(28000, easing = LinearEasing)), label = "a")
    Canvas(Modifier.fillMaxSize()) {
        drawRect(BG)
        val w = size.width
        val h = size.height
        fun blob(cx: Float, cy: Float, r: Float, c: Color) =
            drawCircle(Brush.radialGradient(listOf(c, Color.Transparent), Offset(cx, cy), r), r, Offset(cx, cy))
        blob(w * (0.25f + 0.22f * sin(a)), h * (0.18f + 0.08f * cos(a * 1.3f)), w * 0.85f, CYAN.copy(alpha = 0.17f))
        blob(w * (0.82f + 0.12f * cos(a * 0.8f)), h * (0.48f + 0.12f * sin(a * 1.1f)), w * 0.75f, VIOLET.copy(alpha = 0.15f))
        blob(w * (0.4f + 0.2f * sin(a * 0.7f + 2f)), h * (0.92f + 0.04f * cos(a)), w * 0.9f, GREEN.copy(alpha = 0.08f))
    }
}

// ---------- the orb ----------

@Composable
fun Orb(score: Int, label: String, target: Color, scanning: Boolean) {
    val color by animateColorAsState(target, tween(700), label = "orbColor")
    val shown by animateIntAsState(score, tween(1100, easing = FastOutSlowInEasing), label = "orbNum")
    val sweep by animateFloatAsState(score / 100f, spring(dampingRatio = 0.7f, stiffness = 60f), label = "orbSweep")
    val radar by animateFloatAsState(if (scanning) 1f else 0f, tween(500), label = "orbRadar")
    val tr = rememberInfiniteTransition(label = "orb")
    val ph by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(24000, easing = LinearEasing)), label = "ph")
    val breathe by tr.animateFloat(
        0.92f, 1.06f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "br"
    )
    Box(Modifier.size(250.dp).popIn(80L, 0.6f), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            val ctr = center
            drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.30f), Color.Transparent), ctr, r * breathe), r * breathe, ctr)
            rotate(ph * 720f, ctr) {
                drawCircle(color.copy(alpha = 0.4f), r * 0.96f, ctr,
                    style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(3f, 22f))))
            }
            rotate(-ph * 360f, ctr) {
                drawCircle(Color.White.copy(alpha = 0.12f), r * 0.88f, ctr,
                    style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(40f, 30f))))
            }
            val arcR = r * 0.74f
            val sw = 14.dp.toPx()
            val tl = Offset(ctr.x - arcR, ctr.y - arcR)
            val sz = Size(arcR * 2, arcR * 2)
            drawArc(Color.White.copy(alpha = 0.08f), -90f, 360f, false, tl, sz, style = Stroke(sw))
            rotate(-90f, ctr) {
                drawArc(
                    Brush.sweepGradient(listOf(color.copy(alpha = 0.35f), color, color.copy(alpha = 0.35f)), ctr),
                    0f, 360f * sweep, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
            if (radar > 0.01f) {
                rotate(ph * 2160f, ctr) {
                    drawCircle(
                        Brush.sweepGradient(listOf(Color.Transparent, Color.Transparent, color.copy(alpha = 0.55f * radar)), ctr),
                        arcR * 0.98f, ctr
                    )
                }
            }
            for (i in 0 until 3) {
                val ang = ph * (i + 1) * 2f * PI.toFloat() + i * 2.1f
                val rr = r * (0.93f - i * 0.05f)
                drawCircle(color, (3 - i * 0.5f).dp.toPx(), Offset(ctr.x + cos(ang) * rr, ctr.y + sin(ang) * rr))
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("سلامت گوشی", color = MUTED, fontSize = 12.sp)
            Text("$shown".fa(), color = color, fontSize = 62.sp, fontWeight = FontWeight.Bold)
            Text(label, color = TEXT, fontSize = 14.sp)
        }
    }
}

// ---------- charts & gauges ----------

@Composable
fun SmoothChart(values: List<Float>, lo: Float, hi: Float, color: Color, modifier: Modifier = Modifier) {
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(Unit) { reveal.animateTo(1f, tween(1200, easing = FastOutSlowInEasing)) }
    val tr = rememberInfiniteTransition(label = "dot")
    val pulse by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing)), label = "pulse")
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val dx = size.width / (values.size - 1)
        fun yOf(v: Float) = size.height * 0.95f - ((v - lo) / (hi - lo)).coerceIn(0f, 1f) * size.height * 0.9f
        val path = Path()
        path.moveTo(0f, yOf(values[0]))
        for (i in 1 until values.size) {
            val x0 = (i - 1) * dx
            val x1 = i * dx
            val mx = (x0 + x1) / 2f
            path.cubicTo(mx, yOf(values[i - 1]), mx, yOf(values[i]), x1, yOf(values[i]))
        }
        val fill = Path().apply {
            addPath(path)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        clipRect(left = 0f, top = 0f, right = size.width * reveal.value, bottom = size.height) {
            drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.32f), Color.Transparent)))
        }
        val m = PathMeasure()
        m.setPath(path, false)
        val seg = Path()
        m.getSegment(0f, m.length * reveal.value, seg, true)
        drawPath(seg, color, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
        if (reveal.value > 0.98f) {
            val p = Offset(size.width, yOf(values.last()))
            drawCircle(color.copy(alpha = 0.5f * (1f - pulse)), 6.dp.toPx() + 14.dp.toPx() * pulse, p)
            drawCircle(color, 4.5.dp.toPx(), p)
        }
    }
}

@Composable
fun MiniGauge(progress: Float, color: Color, value: String, label: String, modifier: Modifier = Modifier) {
    val p by animateFloatAsState(progress.coerceIn(0f, 1f), spring(dampingRatio = 0.8f, stiffness = 80f), label = "gauge")
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(86.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val sw = 9.dp.toPx()
                val tl = Offset(sw / 2, sw / 2)
                val sz = Size(size.width - sw, size.height - sw)
                drawArc(Color.White.copy(alpha = 0.08f), 135f, 270f, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                drawArc(color, 135f, 270f * p, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            Text(value.fa(), color = TEXT, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Text(label, color = MUTED, fontSize = 12.sp)
    }
}

@Composable
fun TypingDots() {
    val tr = rememberInfiniteTransition(label = "typing")
    Row(Modifier.padding(horizontal = 6.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in 0 until 3) {
            val y by tr.animateFloat(
                0f, -7f,
                infiniteRepeatable(tween(420, easing = FastOutSlowInEasing), RepeatMode.Reverse, StartOffset(i * 140)),
                label = "dot$i"
            )
            Box(Modifier.size(8.dp).graphicsLayer { translationY = y }.clip(CircleShape).background(CYAN))
        }
    }
}

@Composable
fun GlowButton(text: String, modifier: Modifier = Modifier, filled: Boolean = true, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier.alpha(if (enabled) 1f else 0.5f)
            .bounceClick { if (enabled) onClick() }
            .clip(shape)
            .then(
                if (filled) Modifier.background(Brush.horizontalGradient(listOf(CYAN, VIOLET)))
                else Modifier.border(1.dp, CYAN.copy(alpha = 0.55f), shape)
            )
            .padding(vertical = 13.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (filled) BG else CYAN, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
    }
}
