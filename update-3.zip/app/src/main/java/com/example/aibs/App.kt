package com.example.aibs

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Alerts.channels(this)
        Watchdog.schedule(this)
        if (Store.briefing) BriefingScheduler.schedule(this)
    }
}
