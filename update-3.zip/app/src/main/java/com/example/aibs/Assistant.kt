package com.example.aibs

import java.util.Locale
import kotlin.math.roundToInt

enum class Sev { GOOD, INFO, WARN, BAD }

/** An action button: kind is one of app_settings, uninstall, usage_access, battery_saver, storage, manage_apps, alarm, tab, scan. */
data class Act(val label: String, val kind: String, val arg: String = "", val h: Int = 0, val m: Int = 0)

data class Insight(val sev: Sev, val cat: String, val title: String, val body: String, val act: Act? = null)
data class Routine(val title: String, val body: String, val act: Act? = null)
data class Briefing(
    val health: Int,
    val headline: String,
    val summary: String,
    val parts: List<Pair<String, Int>>,
    val insights: List<Insight>,
    val routines: List<Routine>
)
data class Reply(val text: String, val acts: List<Act> = emptyList())
data class Snapshot(val dev: DeviceInfo, val usage: UsageSummary, val apps: List<AppRisk>, val hasUsage: Boolean, val hour: Int)
data class ChatMsg(val id: Long, val fromUser: Boolean, val text: String, val acts: List<Act> = emptyList(), val typewriter: Boolean = false)

fun String.fa(): String {
    val sb = StringBuilder(length)
    for (ch in this) sb.append(if (ch in '0'..'9') '۰' + (ch - '0') else ch)
    return sb.toString()
}

fun fmtMin(m: Int): String =
    if (m >= 60) "${m / 60} ساعت" + (if (m % 60 > 0) " و ${m % 60} دقیقه" else "") else "$m دقیقه"

private fun f1(x: Float) = String.format(Locale.US, "%.1f", x)

fun greeting(hour: Int) = when (hour) {
    in 5..11 -> "صبح بخیر"
    in 12..16 -> "ظهر بخیر"
    in 17..20 -> "عصر بخیر"
    else -> "شب بخیر"
}

/**
 * Offline rule-based assistant (NOT a language model).
 * Health index = 0.40*Security + 0.15*Memory + 0.15*Storage + 0.15*Battery/Thermal + 0.15*Habits
 */
object Assistant {

    fun brief(s: Snapshot): Briefing {
        val d = s.dev
        val risky = s.apps.filter { !it.trusted && it.level != Level.SAFE }
        val worst = s.apps.filter { !it.trusted }.maxOfOrNull { it.score } ?: 0
        val serious = s.apps.count { !it.trusted && (it.level == Level.MEDIUM || it.level == Level.HIGH) }

        val sec = (100 - worst - 5 * serious).coerceIn(0, 100)
        val mem = (100 - (d.ramPct - 60) * 100 / 38).coerceIn(0, 100)
        val sto = ((d.freeStoragePct - 5) * 100 / 25).coerceIn(0, 100)
        var bat = 100
        if (d.tempC > 38f) bat -= ((d.tempC - 38f) * 8).toInt()
        if (d.batteryPct < 20 && !d.charging) bat -= 30
        if (d.thermal >= 3) bat -= 30
        bat = bat.coerceIn(0, 100)
        var hab = 100
        if (s.hasUsage) {
            if (s.usage.screenMin > 360) hab -= (s.usage.screenMin - 360) / 6
            if (s.usage.nightMin > 30) hab -= 15
            hab -= (s.usage.unused.size * 2).coerceAtMost(20)
        }
        hab = hab.coerceIn(0, 100)
        val health = (0.40 * sec + 0.15 * mem + 0.15 * sto + 0.15 * bat + 0.15 * hab).roundToInt().coerceIn(0, 100)

        val ins = ArrayList<Insight>()

        // security
        if (serious == 0 && s.apps.isNotEmpty())
            ins += Insight(Sev.GOOD, "sec", "امنیت مطمئن است", "در میان ${s.apps.size} برنامهٔ بررسی‌شده مورد پرخطری پیدا نشد.")
        risky.sortedByDescending { it.score }.take(3).forEach { a ->
            val sev = when (a.level) { Level.HIGH -> Sev.BAD; Level.MEDIUM -> Sev.WARN; else -> Sev.INFO }
            ins += Insight(sev, "sec", "«${a.label}» مشکوک است (${a.score}٪)", a.reasons.firstOrNull() ?: "الگوی غیرعادی",
                Act("بررسی برنامه", "app_settings", a.pkg))
        }
        if (!s.hasUsage)
            ins += Insight(Sev.INFO, "sec", "تحلیل رفتاری خاموش است",
                "برای مقایسهٔ مصرف شبکه و تحلیل عادت‌ها، دسترسی Usage Access را فعال کن.", Act("فعال‌سازی", "usage_access"))

        // memory
        if (d.ramPct >= 85)
            ins += Insight(Sev.WARN, "mem", "رم شلوغ است (${d.ramPct}٪)",
                "برنامه‌های زیادی در پس‌زمینه باز است. برنامه‌های اخیر را ببند؛ ری‌استارت هم کمک می‌کند.", Act("مدیریت برنامه‌ها", "manage_apps"))
        else if (d.uptimeH >= 120)
            ins += Insight(Sev.INFO, "mem", "چند روز است ری‌استارت نشده", "گوشی ${d.uptimeH / 24} روز است خاموش نشده؛ یک ری‌استارت حافظه را تازه می‌کند.")

        // storage
        if (d.freeStoragePct < 15)
            ins += Insight(if (d.freeStoragePct < 8) Sev.BAD else Sev.WARN, "sto", "حافظه رو به اتمام است",
                "فقط ${d.freeStoragePct}٪ (${f1(d.freeStorageGb)} گیگابایت) آزاد است. فایل‌های تکراری و برنامه‌های بلااستفاده را پاک کن.",
                Act("مدیریت حافظه", "storage"))

        // battery / heat
        if (d.batteryPct < 20 && !d.charging)
            ins += Insight(Sev.WARN, "bat", "باتری ضعیف است (${d.batteryPct}٪)", "حالت صرفه‌جویی باتری را روشن کن.", Act("صرفه‌جویی باتری", "battery_saver"))
        if (d.tempC >= 40f)
            ins += Insight(if (d.tempC >= 44f) Sev.BAD else Sev.WARN, "bat", "گوشی داغ است (${f1(d.tempC)}°)",
                "از شارژ و بازی هم‌زمان خودداری کن و کاور را بردار تا خنک شود.")
        if (d.charging && d.batteryPct >= 95)
            ins += Insight(Sev.INFO, "bat", "شارژ کامل شد", "برای عمر بیشتر باتری، شارژر را جدا کن.")

        // usage habits
        if (s.hasUsage) {
            if (s.usage.top.isNotEmpty()) {
                val t = s.usage.top.first()
                ins += Insight(Sev.INFO, "use", "بیشترین استفاده: «${t.first}»", "${fmtMin(t.second)} در ۲۴ ساعت گذشته؛ مجموع صفحه ${fmtMin(s.usage.screenMin)}.")
            }
            if (s.usage.screenMin > 300)
                ins += Insight(Sev.WARN, "use", "زمان صفحه زیاد است", "حدود ${fmtMin(s.usage.screenMin)} از گوشی استفاده کرده‌ای. هر ۲۰ دقیقه کمی به دور نگاه کن.")
            if (s.usage.nightMin > 30)
                ins += Insight(Sev.INFO, "use", "استفادهٔ شبانه", "${fmtMin(s.usage.nightMin)} بین ۰ تا ۵ صبح از گوشی استفاده شده؛ این روی خواب اثر می‌گذارد.",
                    Act("ساخت هشدار خواب", "alarm", "زمان خواب؛ گوشی را کنار بگذار", 23, 0))
            if (s.usage.unused.size >= 3)
                ins += Insight(Sev.INFO, "opt", "${s.usage.unused.size} برنامهٔ بلااستفاده", "این برنامه‌ها ۳۰ روز است باز نشده‌اند؛ حذفشان حافظه و باتری آزاد می‌کند.", Act("مشاهده", "tab", "3"))
            val heavy = s.apps.filter { !it.trusted }.maxByOrNull { it.txMb }
            if (heavy != null && heavy.txMb >= 20.0)
                ins += Insight(Sev.INFO, "use", "«${heavy.label}» زیاد داده می‌فرستد",
                    "${f1(heavy.txMb.toFloat())} مگابایت ارسال در ساعت اخیر.", Act("بررسی", "app_settings", heavy.pkg))
        }
        if (ins.isEmpty()) ins += Insight(Sev.GOOD, "opt", "همه‌چیز عالی است", "موردی برای اصلاح پیدا نشد.")

        val sorted = ins.sortedByDescending { it.sev.ordinal }.map { it.copy(title = it.title.fa(), body = it.body.fa()) }

        val headline = when {
            health >= 85 -> "گوشی‌ات در وضعیت عالی است"
            health >= 70 -> "وضعیت خوب است؛ چند نکتهٔ کوچک"
            health >= 50 -> "گوشی کمی توجه می‌خواهد"
            else -> "وضعیت نگران‌کننده است"
        }
        val summary = "باتری ${d.batteryPct}٪${if (d.charging) " (در حال شارژ)" else ""} · رم ${d.ramPct}٪ · حافظهٔ آزاد ${d.freeStoragePct}٪ · " +
            (if (serious == 0) "امنیت بدون مورد خطرناک" else "$serious برنامه نیاز به توجه دارد")

        return Briefing(
            health, headline.fa(), summary.fa(),
            listOf("امنیت (۴۰٪)" to sec, "رم (۱۵٪)" to mem, "حافظه (۱۵٪)" to sto, "باتری و دما (۱۵٪)" to bat, "عادت‌های استفاده (۱۵٪)" to hab),
            sorted, routines(s).map { it.copy(title = it.title.fa(), body = it.body.fa()) }
        )
    }

    private fun routines(s: Snapshot): List<Routine> {
        val d = s.dev
        val r = ArrayList<Routine>()
        val h = s.hour
        when (h) {
            in 5..11 -> r += Routine("روتین صبح",
                "• شارژ را بررسی کن (الان ${d.batteryPct}٪).\n• گزارش امنیتی را مرور کن.\n• اعلان‌های غیرضروری را خاموش کن تا تمرکزت حفظ شود.")
            in 12..17 -> r += Routine("روتین عصر",
                if (s.hasUsage && s.usage.screenMin > 240)
                    "تا الان ${fmtMin(s.usage.screenMin)} از صفحه استفاده کرده‌ای. قاعدهٔ ۲۰-۲۰-۲۰: هر ۲۰ دقیقه، ۲۰ ثانیه به نقطه‌ای دور نگاه کن."
                else "• یک وقفهٔ کوتاه بدون گوشی بگذار.\n• برنامه‌های اخیر را ببند تا رم آزاد شود.")
            else -> {
                r += Routine("روتین شب",
                    "• حالت «مزاحم نشوید» را روشن کن.\n• گوشی را کنار تخت نگذار تا خواب بهتری داشته باشی.\n• باتری را بین ۲۰ تا ۸۰٪ نگه داری عمرش بیشتر می‌شود.",
                    Act("ساخت هشدار خواب ۲۳:۰۰", "alarm", "زمان خواب؛ گوشی را کنار بگذار", 23, 0))
                r += Routine("هشدار بیداری", "برای فردا صبح یک هشدار تنظیم کن.", Act("ساخت هشدار ۷:۰۰", "alarm", "بیداری", 7, 0))
            }
        }
        if (s.usage.unused.size >= 3 || d.freeStoragePct < 30)
            r += Routine("روتین هفتگی", "هفته‌ای یک‌بار: برنامه‌های بلااستفاده را حذف و فایل‌های تکراری را پاک کن.", Act("بهینه‌ساز", "tab", "3"))
        if (!Store.briefing)
            r += Routine("گزارش صبحگاهی", "با فعال‌کردنش، هر روز ساعت ۸ خلاصهٔ وضعیت گوشی را در اعلان می‌بینی.")
        return r
    }

    fun reply(q: String, s: Snapshot, b: Briefing): Reply {
        val t = q.replace('ي', 'ی').replace('ك', 'ک')
        fun has(vararg k: String) = k.any { t.contains(it) }
        val r: Pair<String, List<Act>> = when {
            has("خبر") -> "برای دریافت خبر باید به اینترنت وصل شد و این برنامه عمداً آفلاین است تا هیچ داده‌ای از گوشی‌ات خارج نشود. اگر بخواهی، بعداً یک بخش اختیاری «اخبار امنیتی» اضافه می‌شود." to emptyList()
            has("امنیت", "ویروس", "بدافزار", "مشکوک", "خطر", "هک") -> security(s)
            has("باتری", "شارژ", "دما", "گرم", "داغ") -> battery(s)
            has("رم", "حافظه", "کند", "سرعت", "هنگ", "فضا") -> memory(s)
            has("روتین", "برنامه‌ریزی", "برنامه ریزی", "عادت") -> routine(b)
            has("هشدار", "آلارم", "زنگ", "بیدار") -> alarm()
            has("بهینه") -> optimize(b)
            has("برنامه", "اپ", "مصرف", "استفاده") -> usage(s)
            else -> summary(s, b, t.isBlank() || has("وضعیت", "خلاصه", "حال", "چطور", "گزارش", "سلام"))
        }
        return Reply(r.first.fa(), r.second)
    }

    private fun summary(s: Snapshot, b: Briefing, direct: Boolean): Pair<String, List<Act>> {
        if (!direct) return ("من دستیار آفلاین هستم (مدل زبانی نیستم) و با قواعد و آمار روی خود گوشی کار می‌کنم؛ هیچ داده‌ای ارسال نمی‌شود.\n\nبپرس: وضعیت گوشی، امنیت، باتری، حافظه و رم، برنامه‌ها، روتین پیشنهادی، هشدار یا بهینه‌سازی.") to emptyList()
        val top = b.insights.filter { it.sev != Sev.GOOD }.take(3)
        val text = "${greeting(s.hour)}! سلامت کلی گوشی ${b.health}٪ است. ${b.headline}.\n\n${b.summary}" +
            (if (top.isNotEmpty()) "\n\nمهم‌ترین نکته‌ها:\n" + top.joinToString("\n") { "• ${it.title}" } else "\n\nموردی برای نگرانی نیست.")
        return text to top.mapNotNull { it.act }.take(2)
    }

    private fun security(s: Snapshot): Pair<String, List<Act>> {
        val risky = s.apps.filter { !it.trusted && it.level != Level.SAFE }.sortedByDescending { it.score }
        if (risky.isEmpty()) {
            val note = if (!s.hasUsage) "\n\nتوجه: تحلیل رفتاری شبکه خاموش است و فقط مجوزها و منبع نصب بررسی شده‌اند. برای دقت بیشتر Usage Access را فعال کن." else ""
            return ("از ${s.apps.size} برنامهٔ بررسی‌شده هیچ‌کدام رفتار پرخطری نشان نمی‌دهند.$note") to
                (if (!s.hasUsage) listOf(Act("فعال‌سازی", "usage_access")) else emptyList())
        }
        val top = risky.take(3)
        val txt = "این موارد توجه می‌خواهند:\n" +
            top.joinToString("\n") { "• «${it.label}» (${it.score}٪): ${it.reasons.firstOrNull() ?: "الگوی غیرعادی"}" } +
            "\n\nاگر برنامه را نمی‌شناسی، توقف اجباری یا حذفش کن."
        val f = top.first()
        return txt to listOf(Act("توقف «${f.label}»", "app_settings", f.pkg), Act("حذف «${f.label}»", "uninstall", f.pkg))
    }

    private fun battery(s: Snapshot): Pair<String, List<Act>> {
        val d = s.dev
        val sb = StringBuilder("باتری ${d.batteryPct}٪ ${if (d.charging) "(در حال شارژ)" else "(روی باتری)"}، دما ${f1(d.tempC)}°، فشار حرارتی: ${thermalLabel(d.thermal)}.")
        if (d.tempC >= 40f) sb.append("\n\nگوشی داغ است؛ شارژ و کار سنگین را هم‌زمان انجام نده و کاور را بردار.")
        else if (d.batteryPct < 20 && !d.charging) sb.append("\n\nباتری ضعیف است؛ صرفه‌جویی باتری را روشن کن.")
        else sb.append("\n\nوضعیت باتری خوب است.")
        return sb.toString() to (if (d.batteryPct < 40 && !d.charging) listOf(Act("صرفه‌جویی باتری", "battery_saver")) else emptyList())
    }

    private fun memory(s: Snapshot): Pair<String, List<Act>> {
        val d = s.dev
        val sb = StringBuilder("رم ${d.ramPct}٪ پر است، ${d.freeStoragePct}٪ (${f1(d.freeStorageGb)} گیگابایت) حافظه آزاد دارد و ${d.uptimeH} ساعت است روشن مانده.")
        if (d.ramPct >= 85) sb.append("\n\nرم شلوغ است؛ برنامه‌های اخیر را ببند.")
        if (d.freeStoragePct < 15) sb.append("\n\nحافظه کم است؛ فایل‌های تکراری و برنامه‌های بلااستفاده را پاک کن.")
        if (d.uptimeH >= 120) sb.append("\n\nیک ری‌استارت کمک می‌کند.")
        return sb.toString() to listOf(Act("مدیریت حافظه", "storage"), Act("بهینه‌ساز", "tab", "3"))
    }

    private fun usage(s: Snapshot): Pair<String, List<Act>> {
        if (!s.hasUsage) return "برای دیدن مصرف برنامه‌ها باید Usage Access را فعال کنی." to listOf(Act("فعال‌سازی", "usage_access"))
        val u = s.usage
        val top = if (u.top.isEmpty()) "داده‌ای برای ۲۴ ساعت گذشته نیست." else u.top.joinToString("\n") { "• ${it.first}: ${fmtMin(it.second)}" }
        return ("مجموع زمان صفحه در ۲۴ ساعت گذشته: ${fmtMin(u.screenMin)}.\n\n$top\n\n${u.unused.size} برنامه ۳۰ روز است استفاده نشده.") to listOf(Act("بهینه‌ساز", "tab", "3"))
    }

    private fun routine(b: Briefing): Pair<String, List<Act>> {
        val txt = b.routines.joinToString("\n\n") { "▪ ${it.title}\n${it.body}" }
        return txt to b.routines.mapNotNull { it.act }.take(2)
    }

    private fun alarm(): Pair<String, List<Act>> =
        "دو هشدار پیشنهادی: خواب ساعت ۲۳:۰۰ و بیداری ساعت ۷:۰۰. با دکمه‌ها مستقیم در برنامهٔ ساعت ساخته می‌شوند." to
            listOf(Act("هشدار خواب ۲۳:۰۰", "alarm", "زمان خواب؛ گوشی را کنار بگذار", 23, 0), Act("هشدار بیداری ۷:۰۰", "alarm", "بیداری", 7, 0))

    private fun optimize(b: Briefing): Pair<String, List<Act>> {
        val l = b.insights.filter { it.cat in setOf("mem", "sto", "bat", "opt", "use") && it.sev != Sev.GOOD }.take(4)
        if (l.isEmpty()) return "همه‌چیز بهینه است و کار خاصی لازم نیست." to emptyList()
        return ("برای بهینه‌سازی:\n" + l.joinToString("\n") { "• ${it.title}: ${it.body}" } +
            "\n\nنکته: اندروید اجازهٔ پاک‌کردن رم برنامه‌های دیگر را نمی‌دهد؛ حذف برنامه‌های بلااستفاده و آزادکردن حافظه واقعاً اثر دارد.") to
            listOf(Act("بهینه‌ساز", "tab", "3"))
    }
}
