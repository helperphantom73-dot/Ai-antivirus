package com.example.aibs

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar
import java.util.Locale

@Composable
fun CountStat(title: String, value: Int, suffix: String, color: Color, modifier: Modifier = Modifier) {
    val v by animateIntAsState(value, tween(900, easing = FastOutSlowInEasing), label = "count")
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier.clip(shape).background(Color(0xB8101623)).border(1.dp, Color(0x22FFFFFF), shape).padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("$v$suffix".fa(), color = color, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Text(title, color = MUTED, fontSize = 11.sp)
    }
}

@Composable
fun HomeScreen(st: UiState, onTab: (Int) -> Unit) {
    val c = LocalContext.current
    val b = st.brief
    val health = b?.health ?: st.deviceScore
    val dev = st.dev
    val last = st.samples.lastOrNull()
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = screenPad(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.staggerIn(0)) {
                Text(greeting(hour), color = TEXT, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (st.running) "● پایش زنده فعال است" else "○ پایش خاموش است",
                    color = if (st.running) GREEN else MUTED, fontSize = 13.sp
                )
            }
        }
        item { Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Orb(health, scoreLabel(health), scoreColor(health), st.scanning) } }
        item {
            Text(
                b?.headline ?: "در حال تحلیل…", color = TEXT, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().staggerIn(1)
            )
        }
        item {
            Row(Modifier.staggerIn(2), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val bat = dev?.batteryPct ?: 0
                val ram = dev?.ramPct ?: 0
                val free = dev?.freeStoragePct ?: 0
                CountStat("باتری", bat, "٪", if (bat < 20) RED else GREEN, Modifier.weight(1f))
                CountStat("رم", ram, "٪", if (ram >= 85) RED else if (ram >= 70) AMBER else CYAN, Modifier.weight(1f))
                CountStat("حافظهٔ آزاد", free, "٪", if (free < 10) RED else if (free < 20) AMBER else CYAN, Modifier.weight(1f))
                CountStat("دما", (last?.tempC ?: dev?.tempC ?: 0f).toInt(), "°", if ((last?.tempC ?: 0f) >= 40f) RED else AMBER, Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.staggerIn(3), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GlowButton(if (st.running) "توقف پایش" else "شروع پایش", Modifier.weight(1f)) {
                    if (st.running) stopMon(c) else startMon(c)
                }
                GlowButton(if (st.scanning) "در حال اسکن…" else "اسکن اکنون", Modifier.weight(1f), filled = false, enabled = !st.scanning) {
                    Hub.scanNow(c)
                }
            }
        }
        item {
            Panel(Modifier.staggerIn(4)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("خلاصهٔ هوشمند", color = CYAN, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("آفلاین", color = MUTED, fontSize = 11.sp)
                }
                Text(b?.summary ?: "", color = MUTED, fontSize = 12.sp)
                val shown = b?.insights?.filter { it.sev != Sev.GOOD }?.take(3).orEmpty()
                if (shown.isEmpty() && b != null) Text("موردی برای نگرانی نیست ✓", color = GREEN, fontSize = 13.sp)
                shown.forEach { InsightRow(it, onTab) }
                GlowButton("گفتگو با دستیار", Modifier.fillMaxWidth(), filled = false) { onTab(1) }
            }
        }
        if (!st.usageAccess) item {
            Panel(Modifier.staggerIn(5)) {
                Text("تحلیل رفتاری غیرفعال است", color = AMBER, fontWeight = FontWeight.Bold)
                Text(
                    "با فعال‌کردن Usage Access، مصرف شبکهٔ هر برنامه با الگوی عادی خودش مقایسه می‌شود و دستیار عادت‌هایت را هم می‌فهمد.",
                    color = MUTED, fontSize = 12.sp
                )
                GlowButton("فعال‌سازی دسترسی", Modifier.fillMaxWidth(), filled = false) { openUsageAccess(c) }
            }
        }
        item {
            Panel(Modifier.staggerIn(6)) {
                Text("مصرف رم (زنده)", color = MUTED, fontSize = 12.sp)
                SmoothChart(st.samples.map { it.ramPct }, 0f, 100f, CYAN, Modifier.fillMaxWidth().height(90.dp))
            }
        }
        item {
            Panel {
                Text("دمای باتری (°C)", color = MUTED, fontSize = 12.sp)
                SmoothChart(st.samples.map { it.tempC }, 20f, 50f, AMBER, Modifier.fillMaxWidth().height(90.dp))
                Text(
                    "فشار حرارتی: ${thermalLabel(st.thermal)}  ·  آخرین اسکن: " +
                        (if (st.lastScan == 0L) "—" else String.format(Locale.US, "%tH:%<tM", st.lastScan)),
                    color = MUTED, fontSize = 11.sp
                )
            }
        }
    }
}
