package com.example.aibs

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.Calendar

object Hub {
    private val _s = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _s.asStateFlow()
    private val _chat = MutableStateFlow<List<ChatMsg>>(emptyList())
    val chat: StateFlow<List<ChatMsg>> = _chat.asStateFlow()
    private val _typing = MutableStateFlow(false)
    val typing: StateFlow<Boolean> = _typing.asStateFlow()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Mutex()
    private var nextId = 1L

    fun setRunning(v: Boolean) = _s.update { it.copy(running = v) }

    fun refreshMeta(c: Context) {
        _s.update { it.copy(usageAccess = Metrics.hasUsageAccess(c), events = Store.events(), thermal = Metrics.thermal(c)) }
        rebuildBrief(c)
    }

    fun pushSample(c: Context) {
        val s = Metrics.sample(c)
        val th = Metrics.thermal(c)
        _s.update { it.copy(samples = (it.samples + s).takeLast(90), thermal = th) }
    }

    private fun snapshot(c: Context): Snapshot {
        val st = _s.value
        return Snapshot(Metrics.device(c), st.usage, st.apps, st.usageAccess, Calendar.getInstance().get(Calendar.HOUR_OF_DAY))
    }

    fun rebuildBrief(c: Context) {
        try {
            val sn = snapshot(c)
            val b = Assistant.brief(sn)
            _s.update { it.copy(brief = b, dev = sn.dev) }
        } catch (e: Exception) {
            // ignore
        }
    }

    fun scanNow(c: Context) {
        val app = c.applicationContext
        scope.launch { runScan(app) }
    }

    suspend fun runScan(c: Context) = lock.withLock {
        _s.update { it.copy(scanning = true, usageAccess = Metrics.hasUsageAccess(c)) }
        try {
            val apps = Scanner.scan(c)
            Alerts.process(c, apps)
            val us = if (_s.value.usageAccess) {
                try { Usage.summarize(c) } catch (e: Exception) { UsageSummary() }
            } else UsageSummary()
            _s.update { it.copy(apps = apps, usage = us, events = Store.events(), lastScan = System.currentTimeMillis()) }
            rebuildBrief(c)
        } catch (e: Exception) {
            // keep previous results
        } finally {
            _s.update { it.copy(scanning = false) }
        }
    }

    fun toggleTrust(c: Context, pkg: String) {
        val w = Store.whitelist.toMutableSet()
        if (!w.add(pkg)) w.remove(pkg)
        Store.whitelist = w
        scanNow(c)
    }

    fun clearEvents() {
        Store.clearEvents()
        _s.update { it.copy(events = emptyList()) }
    }

    // ---- assistant chat ----
    fun ask(c: Context, q: String, showUser: Boolean = true) {
        val app = c.applicationContext
        val text = q.trim()
        if (showUser && text.isEmpty()) return
        if (showUser) _chat.update { it + ChatMsg(nextId++, true, text) }
        scope.launch {
            _typing.value = true
            delay(650)
            val sn = snapshot(app)
            val b = Assistant.brief(sn)
            val r = Assistant.reply(text, sn, b)
            _typing.value = false
            _chat.update { it + ChatMsg(nextId++, false, r.text, r.acts, true) }
        }
    }

    fun greet(c: Context) {
        if (_chat.value.isEmpty()) ask(c, "وضعیت", showUser = false)
    }

    fun markShown(id: Long) {
        _chat.update { l -> l.map { if (it.id == id) it.copy(typewriter = false) else it } }
    }
}
