package com.example.aibs

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val CHIPS = listOf("وضعیت گوشی", "امنیت", "باتری", "حافظه و رم", "برنامه‌ها", "روتین پیشنهادی", "هشدار", "بهینه‌سازی")

@Composable
fun Bubble(m: ChatMsg, onTab: (Int) -> Unit) {
    val c = LocalContext.current
    var shown by remember(m.id) { mutableIntStateOf(if (m.typewriter) 0 else m.text.length) }
    LaunchedEffect(m.id, m.typewriter) {
        if (m.typewriter) {
            while (shown < m.text.length) {
                shown = (shown + 3).coerceAtMost(m.text.length)
                delay(16)
            }
            Hub.markShown(m.id)
        }
    }
    Box(Modifier.fillMaxWidth().popIn(0L, 0.85f), contentAlignment = if (m.fromUser) Alignment.CenterStart else Alignment.CenterEnd) {
        val shape = RoundedCornerShape(20.dp)
        Column(
            Modifier.widthIn(max = 310.dp).animateContentSize().clip(shape)
                .background(if (m.fromUser) CYAN.copy(alpha = 0.18f) else Color(0xCC101623))
                .border(1.dp, if (m.fromUser) CYAN.copy(alpha = 0.4f) else Color(0x22FFFFFF), shape)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(m.text.take(shown), color = TEXT, fontSize = 14.sp, lineHeight = 22.sp)
            AnimatedVisibility(!m.typewriter && m.acts.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    m.acts.forEach { a ->
                        GlowButton(a.label, filled = false) { runAct(c, a, onTab) }
                    }
                }
            }
        }
    }
}

@Composable
fun AssistantScreen(st: UiState, onTab: (Int) -> Unit) {
    val c = LocalContext.current
    val chat by Hub.chat.collectAsState()
    val typing by Hub.typing.collectAsState()
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    LaunchedEffect(Unit) { Hub.greet(c) }
    LaunchedEffect(chat.size, typing) {
        val n = chat.size + (if (typing) 1 else 0)
        if (n > 0) listState.animateScrollToItem(n - 1)
    }

    fun send(t: String) {
        if (t.isBlank()) return
        Hub.ask(c, t)
        input = ""
    }

    Column(Modifier.fillMaxSize().imePadding().padding(top = top + 12.dp, bottom = if (imeOpen) 8.dp else 100.dp)) {
        Column(Modifier.padding(horizontal = 16.dp)) {
            Text("دستیار هوشمند", color = TEXT, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("آفلاین · فارسی · بدون ارسال داده", color = MUTED, fontSize = 12.sp)
        }
        LazyColumn(
            Modifier.weight(1f).fillMaxWidth(), state = listState,
            contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(chat, key = { it.id }) { Bubble(it, onTab) }
            if (typing) item {
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.CenterEnd) {
                    Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xCC101623)).padding(10.dp)) { TypingDots() }
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CHIPS.forEach { t ->
                Box(
                    Modifier.bounceClick { send(t) }.clip(RoundedCornerShape(50))
                        .background(Color(0x1AFFFFFF)).border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(50))
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) { Text(t, color = TEXT, fontSize = 12.sp) }
            }
        }
        Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), singleLine = true,
                placeholder = { Text("بپرس: وضعیت گوشی؟", color = MUTED) },
                shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send(input) }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CYAN, unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedTextColor = TEXT, unfocusedTextColor = TEXT, cursorColor = CYAN
                )
            )
            Box(
                Modifier.size(52.dp).bounceClick { send(input) }.clip(RoundedCornerShape(26.dp)).background(CYAN),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Filled.Send, null, tint = BG) }
        }
    }
}
