package com.example.aibs

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import java.util.Calendar

/** Screen-time, night usage and unused-app analysis (needs Usage Access). */
object Usage {
    private const val DAY = 86_400_000L

    @Suppress("DEPRECATION")
    fun summarize(c: Context): UsageSummary {
        val pm = c.packageManager
        val usm = c.getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val home = homePkg(pm)

        val ev = usm.queryEvents(now - DAY, now)
        val e = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        var night = 0L
        val cal = Calendar.getInstance()

        fun add(pkg: String, s: Long, en: Long) {
            if (en <= s || pkg == home || pkg == c.packageName || pkg == "com.android.systemui") return
            total[pkg] = (total[pkg] ?: 0L) + (en - s)
            var t = s
            while (t < en) {
                cal.timeInMillis = t
                if (cal.get(Calendar.HOUR_OF_DAY) < 5) night += minOf(300_000L, en - t)
                t += 300_000L
            }
        }

        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> open[e.packageName] = e.timeStamp
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    val s = open.remove(e.packageName)
                    if (s != null) add(e.packageName, s, e.timeStamp)
                }
            }
        }
        for ((p, s) in open) add(p, s, now)

        val top = total.entries.sortedByDescending { it.value }
            .map { label(pm, it.key) to (it.value / 60_000L).toInt() }
            .filter { it.second > 0 }
            .take(3)
        val screenMin = (total.values.sum() / 60_000L).toInt()

        // unused apps (30 days)
        val unused = ArrayList<Unused>()
        val stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_BEST, now - 30 * DAY, now)
        if (!stats.isNullOrEmpty()) {
            val last = HashMap<String, Long>()
            stats.forEach { last[it.packageName] = maxOf(last[it.packageName] ?: 0L, it.lastTimeUsed) }
            val limit = now - 30 * DAY
            val apps = if (Build.VERSION.SDK_INT >= 33)
                pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
            else pm.getInstalledApplications(0)
            for (ai in apps) {
                if (unused.size >= 20) break
                val sys = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
                if (sys || ai.packageName == c.packageName) continue
                if (pm.getLaunchIntentForPackage(ai.packageName) == null) continue
                if ((last[ai.packageName] ?: 0L) >= limit) continue
                val installed = try { pm.getPackageInfo(ai.packageName, 0).firstInstallTime } catch (x: Exception) { now }
                if (installed > limit) continue
                unused += Unused(label(pm, ai.packageName), ai.packageName)
            }
        }
        return UsageSummary(screenMin, top, (night / 60_000L).toInt(), unused)
    }

    @Suppress("DEPRECATION")
    private fun homePkg(pm: PackageManager): String? = try {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)?.activityInfo?.packageName
    } catch (e: Exception) {
        null
    }

    private fun label(pm: PackageManager, pkg: String): String = try {
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg
    }
}
