package com.example.aibs

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.Settings

private fun go(c: Context, i: Intent) = try {
    c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
} catch (e: Exception) { }

fun setAlarm(c: Context, hour: Int, min: Int, label: String) = go(
    c,
    Intent(AlarmClock.ACTION_SET_ALARM)
        .putExtra(AlarmClock.EXTRA_HOUR, hour)
        .putExtra(AlarmClock.EXTRA_MINUTES, min)
        .putExtra(AlarmClock.EXTRA_MESSAGE, label)
)

fun openBatterySaver(c: Context) = go(c, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
fun openStorage(c: Context) = go(c, Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
fun openManageApps(c: Context) = go(c, Intent(Settings.ACTION_APPLICATION_SETTINGS))

fun runAct(c: Context, a: Act, onTab: (Int) -> Unit = {}) {
    when (a.kind) {
        "app_settings" -> openAppSettings(c, a.arg)
        "uninstall" -> uninstallApp(c, a.arg)
        "usage_access" -> openUsageAccess(c)
        "battery_saver" -> openBatterySaver(c)
        "storage" -> openStorage(c)
        "manage_apps" -> openManageApps(c)
        "alarm" -> setAlarm(c, a.h, a.m, a.arg)
        "tab" -> onTab(a.arg.toIntOrNull() ?: 0)
        "scan" -> Hub.scanNow(c)
    }
}
