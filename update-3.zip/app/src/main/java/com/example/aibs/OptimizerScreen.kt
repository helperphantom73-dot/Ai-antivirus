package com.example.aibs

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PartBar(name: String, value: Int) {
    val p by animateFloatAsState(value / 100f, spring(dampingRatio = 0.85f, stiffness = 70f), label = "bar")
    val col = scoreColor(value)
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row {
            Text(name, color = TEXT, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("$value".fa(), color = col, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color(0x14FFFFFF))) {
            Box(Modifier.fillMaxWidth(p.coerceIn(0.02f, 1f)).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(col))
        }
    }
}

@Composable
fun OptimizerScreen(st: UiState, onTab: (Int) -> Unit) {
    val c = LocalContext.current
    val d = st.dev ?: DeviceInfo()
    val b = st.brief
    val opt = b?.insights?.filter { it.cat in setOf("mem", "sto", "bat", "opt", "use") && it.sev != Sev.GOOD }.orEmpty()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = screenPad(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Column(Modifier.staggerIn(0)) {
                Text("بهینه‌ساز", color = TEXT, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("اقدام‌های واقعی که روی سرعت و باتری اثر دارند", color = MUTED, fontSize = 12.sp)
            }
        }
        item {
            Panel(Modifier.staggerIn(1)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    MiniGauge(d.ramPct / 100f, if (d.ramPct >= 85) RED else if (d.ramPct >= 70) AMBER else GREEN, "${d.ramPct}٪", "رم")
                    MiniGauge((100 - d.freeStoragePct) / 100f, if (d.freeStoragePct < 10) RED else if (d.freeStoragePct < 20) AMBER else GREEN, "${100 - d.freeStoragePct}٪", "حافظهٔ پر")
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    MiniGauge(d.batteryPct / 100f, if (d.batteryPct < 20) RED else GREEN, "${d.batteryPct}٪", "باتری")
                    MiniGauge((d.uptimeH / 168f), if (d.uptimeH >= 120) AMBER else GREEN, "${d.uptimeH} س", "روشن‌بودن")
                }
            }
        }
        item {
            Panel(Modifier.staggerIn(2)) {
                Text("پیشنهادهای بهینه‌سازی", color = CYAN, fontWeight = FontWeight.Bold)
                if (opt.isEmpty()) Text("همه‌چیز بهینه است ✓", color = GREEN, fontSize = 13.sp)
                opt.forEach { InsightRow(it, onTab) }
            }
        }
        item {
            Panel(Modifier.staggerIn(3)) {
                Text("میان‌برهای سیستم", color = CYAN, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GlowButton("صرفه‌جویی باتری", Modifier.weight(1f), filled = false) { openBatterySaver(c) }
                    GlowButton("حافظه", Modifier.weight(1f), filled = false) { openStorage(c) }
                    GlowButton("برنامه‌ها", Modifier.weight(1f), filled = false) { openManageApps(c) }
                }
            }
        }
        item {
            Text(
                if (st.usage.unused.isEmpty()) "برنامهٔ بلااستفاده‌ای پیدا نشد" else "برنامه‌های بلااستفاده (۳۰ روز)",
                color = TEXT, fontWeight = FontWeight.Bold, fontSize = 16.sp
            )
        }
        items(st.usage.unused.take(10), key = { it.pkg }) { u ->
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(u.label, color = TEXT, modifier = Modifier.weight(1f), maxLines = 1)
                    GlowButton("حذف", filled = false) { uninstallApp(c, u.pkg) }
                }
            }
        }
        item {
            Panel {
                Text("چرا «پاک‌کردن رم» نیست؟", color = AMBER, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(
                    "اندروید خودش رم را مدیریت می‌کند و به برنامه‌ها اجازهٔ بستن برنامه‌های دیگر را نمی‌دهد. دکمه‌های «بوستر» عملاً اثر پایداری ندارند. اقدام‌های بالا (حذف برنامه‌های بلااستفاده، آزادکردن حافظه، صرفه‌جویی باتری) واقعاً کمک می‌کنند.",
                    color = MUTED, fontSize = 12.sp
                )
            }
        }
        b?.let { br ->
            item {
                Panel {
                    Text("تجزیهٔ امتیاز سلامت", color = CYAN, fontWeight = FontWeight.Bold)
                    br.parts.forEach { PartBar(it.first, it.second) }
                }
            }
        }
    }
}
