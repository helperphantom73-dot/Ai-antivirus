package com.example.aibs

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.app.NotificationCompat

object Alerts {
    const val CH_SVC = "monitor"
    const val CH_ALERT = "alerts"
    private const val COOLDOWN = 12 * 3_600_000L

    fun channels(c: Context) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH_SVC, "پایش پس‌زمینه", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "هشدارهای امنیتی", NotificationManager.IMPORTANCE_HIGH))
    }

    fun serviceNotif(c: Context, text: String): Notification {
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(c, CH_SVC)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("AI Behavioral Security")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setContentIntent(open)
            .build()
    }

    fun process(c: Context, apps: List<AppRisk>) {
        val now = System.currentTimeMillis()
        for (a in apps) {
            if (a.trusted) continue
            val hit = a.level == Level.HIGH || (a.level == Level.MEDIUM && a.dynamic >= 20)
            if (!hit || now - Store.lastAlert(a.pkg) < COOLDOWN) continue
            Store.setLastAlert(a.pkg, now)
            Store.addEvent(ThreatEvent(now, a.pkg, a.label, a.score, a.reasons.joinToString(" • ")))
            notifyThreat(c, a)
        }
    }

    private fun notifyThreat(c: Context, a: AppRisk) {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val settings = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val delete = Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val open = Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val n = NotificationCompat.Builder(c, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle("رفتار مشکوک: ${a.label} (${a.score})")
            .setContentText(a.reasons.firstOrNull() ?: "الگوی غیرعادی")
            .setStyle(NotificationCompat.BigTextStyle().bigText(a.reasons.joinToString("\n• ", prefix = "• ")))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(PendingIntent.getActivity(c, 1, open, flags))
            .addAction(0, "توقف اجباری", PendingIntent.getActivity(c, a.pkg.hashCode(), settings, flags))
            .addAction(0, "حذف برنامه", PendingIntent.getActivity(c, a.pkg.hashCode() + 1, delete, flags))
            .build()
        c.getSystemService(NotificationManager::class.java).notify(a.pkg.hashCode(), n)
    }

    fun notifyStopped(c: Context) {
        val open = PendingIntent.getActivity(c, 2, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("پایش امنیتی متوقف شد")
            .setContentText("برای ازسرگیری، برنامه را باز کنید.")
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        c.getSystemService(NotificationManager::class.java).notify(9001, n)
    }
}
