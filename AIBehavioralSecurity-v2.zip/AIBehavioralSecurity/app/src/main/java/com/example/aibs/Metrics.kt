package com.example.aibs

import android.app.ActivityManager
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.os.Process

/**
 * Real device metrics that a normal (non-root) app is allowed to read.
 * NOTE: /proc/stat and /proc/net/tcp are blocked for apps on modern Android,
 * so system-wide CPU is intentionally NOT shown. Thermal status is used instead.
 */
object Metrics {
    fun sample(c: Context): Sample {
        val am = c.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val ram = (mi.totalMem - mi.availMem) * 100f / mi.totalMem
        val b = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val temp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        return Sample(System.currentTimeMillis(), ram, temp)
    }

    fun thermal(c: Context): Int =
        if (Build.VERSION.SDK_INT >= 29) c.getSystemService(PowerManager::class.java).currentThermalStatus else 0

    fun interactive(c: Context): Boolean = c.getSystemService(PowerManager::class.java).isInteractive

    @Suppress("DEPRECATION")
    fun hasUsageAccess(c: Context): Boolean {
        val ops = c.getSystemService(AppOpsManager::class.java)
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
