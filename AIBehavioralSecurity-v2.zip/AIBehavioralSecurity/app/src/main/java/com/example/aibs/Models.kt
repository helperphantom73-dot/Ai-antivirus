package com.example.aibs

enum class Level(val fa: String) {
    SAFE("ایمن"), WATCH("نظارت"), MEDIUM("مشکوک"), HIGH("خطرناک")
}

data class AppRisk(
    val pkg: String,
    val label: String,
    val score: Int,
    val dynamic: Int,
    val level: Level,
    val reasons: List<String>,
    val txMb: Double,
    val rxMb: Double,
    val fgMin: Int,
    val trusted: Boolean
)

data class ThreatEvent(
    val time: Long,
    val pkg: String,
    val label: String,
    val score: Int,
    val reason: String
)

data class Sample(val t: Long, val ramPct: Float, val tempC: Float)

data class UiState(
    val apps: List<AppRisk> = emptyList(),
    val samples: List<Sample> = emptyList(),
    val events: List<ThreatEvent> = emptyList(),
    val thermal: Int = 0,
    val running: Boolean = false,
    val usageAccess: Boolean = false,
    val scanning: Boolean = false,
    val lastScan: Long = 0L
) {
    /** 100 = completely safe. */
    val deviceScore: Int
        get() {
            val worst = apps.filter { !it.trusted }.maxOfOrNull { it.score } ?: 0
            val heat = if (thermal >= 3) 15 else 0
            return (100 - worst - heat).coerceIn(0, 100)
        }
}
