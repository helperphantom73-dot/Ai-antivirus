package com.example.aibs

import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Single source of truth shared by the service and the UI (same process). */
object Hub {
    private val _s = MutableStateFlow(UiState())
    val state: StateFlow<UiState> = _s.asStateFlow()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val lock = Mutex()

    fun setRunning(v: Boolean) = _s.update { it.copy(running = v) }

    fun refreshMeta(c: Context) = _s.update {
        it.copy(usageAccess = Metrics.hasUsageAccess(c), events = Store.events(), thermal = Metrics.thermal(c))
    }

    fun pushSample(c: Context) {
        val s = Metrics.sample(c)
        val th = Metrics.thermal(c)
        _s.update { it.copy(samples = (it.samples + s).takeLast(90), thermal = th) }
    }

    fun scanNow(c: Context) {
        val app = c.applicationContext
        scope.launch { runScan(app) }
    }

    suspend fun runScan(c: Context) = lock.withLock {
        _s.update { it.copy(scanning = true, usageAccess = Metrics.hasUsageAccess(c)) }
        try {
            val apps = Scanner.scan(c)
            Alerts.process(c, apps)
            _s.update {
                it.copy(apps = apps, events = Store.events(), lastScan = System.currentTimeMillis())
            }
        } catch (e: Exception) {
            // keep previous results
        } finally {
            _s.update { it.copy(scanning = false) }
        }
    }

    fun toggleTrust(c: Context, pkg: String) {
        val w = Store.whitelist.toMutableSet()
        if (!w.add(pkg)) w.remove(pkg)
        Store.whitelist = w
        scanNow(c)
    }

    fun clearEvents() {
        Store.clearEvents()
        _s.update { it.copy(events = emptyList()) }
    }
}
