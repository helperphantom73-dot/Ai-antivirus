package com.example.aibs

import android.content.Context
import android.os.PowerManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings as SettingsIcon
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val BG = Color(0xFF070A12)
val PANEL = Color(0xFF101623)
val CYAN = Color(0xFF00E5FF)
val GREEN = Color(0xFF00E676)
val AMBER = Color(0xFFFFB300)
val RED = Color(0xFFFF5252)
val TEXT = Color(0xFFE6EDF7)
val MUTED = Color(0xFF8A97AD)

fun Level.color() = when (this) {
    Level.SAFE -> GREEN
    Level.WATCH -> CYAN
    Level.MEDIUM -> AMBER
    Level.HIGH -> RED
}

fun scoreColor(s: Int) = if (s >= 80) GREEN else if (s >= 55) AMBER else RED
fun scoreLabel(s: Int) = if (s >= 80) "ایمن" else if (s >= 55) "نیازمند توجه" else "در خطر"
fun thermalLabel(t: Int) = when (t) {
    0 -> "عادی"; 1 -> "سبک"; 2 -> "متوسط"; 3 -> "شدید"; 4 -> "بحرانی"; 5 -> "اضطراری"; else -> "خاموشی"
}

@Composable
fun AibsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = CYAN, onPrimary = BG, secondary = CYAN,
            background = BG, surface = PANEL, onBackground = TEXT, onSurface = TEXT
        )
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) { content() }
    }
}

@Composable
fun AibsApp() {
    val st by Hub.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("داشبورد" to Icons.Filled.Home, "برنامه‌ها" to Icons.Filled.Search,
        "هشدارها" to Icons.Filled.Warning, "تنظیمات" to Icons.Filled.SettingsIcon)
    Scaffold(
        containerColor = BG,
        bottomBar = {
            NavigationBar(containerColor = PANEL) {
                tabs.forEachIndexed { i, (label, icon) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = BG, indicatorColor = CYAN,
                            selectedTextColor = CYAN, unselectedIconColor = MUTED, unselectedTextColor = MUTED
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> Dashboard(st)
                1 -> AppsScreen(st)
                2 -> AlertsScreen(st)
                else -> SettingsScreen(st)
            }
        }
    }
}

// ---------- shared pieces ----------

@Composable
fun Panel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(PANEL).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp), content = content
    )
}

@Composable
fun Stat(title: String, value: String, modifier: Modifier = Modifier) {
    Panel(modifier) {
        Text(title, color = MUTED, fontSize = 12.sp)
        Text(value, color = TEXT, fontSize = 20.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ScoreRing(score: Int, label: String, color: Color) {
    val sweep by animateFloatAsState(score / 100f * 360f, tween(800), label = "ring")
    Box(Modifier.size(200.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val tl = Offset(stroke / 2, stroke / 2)
            val sz = Size(size.width - stroke, size.height - stroke)
            drawArc(Color(0x22FFFFFF), -90f, 360f, false, tl, sz, style = Stroke(stroke))
            drawArc(color, -90f, sweep, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$score", fontSize = 56.sp, fontWeight = FontWeight.Bold, color = color)
            Text(label, color = MUTED, fontSize = 14.sp)
        }
    }
}

@Composable
fun LineChart(values: List<Float>, lo: Float, hi: Float, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        if (values.size < 2) return@Canvas
        val dx = size.width / (values.size - 1)
        val path = Path()
        values.forEachIndexed { i, v ->
            val y = size.height - ((v - lo) / (hi - lo)).coerceIn(0f, 1f) * size.height
            if (i == 0) path.moveTo(0f, y) else path.lineTo(i * dx, y)
        }
        val fill = Path().apply {
            addPath(path)
            lineTo(size.width, size.height)
            lineTo(0f, size.height)
            close()
        }
        drawPath(fill, Brush.verticalGradient(listOf(color.copy(alpha = 0.3f), Color.Transparent)))
        drawPath(path, color, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

// ---------- dashboard ----------

@Composable
fun Dashboard(st: UiState) {
    val c = LocalContext.current
    val last = st.samples.lastOrNull()
    val risky = st.apps.filter { !it.trusted && it.score >= 20 }.take(3)
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Column {
                Text("مرکز امنیت رفتاری", color = TEXT, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text(if (st.running) "● پایش زنده فعال است" else "○ پایش خاموش است",
                    color = if (st.running) GREEN else MUTED, fontSize = 13.sp)
            }
        }
        item {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                ScoreRing(st.deviceScore, scoreLabel(st.deviceScore), scoreColor(st.deviceScore))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Stat("RAM", last?.let { "${it.ramPct.toInt()}%" } ?: "—", Modifier.weight(1f))
                Stat("دمای باتری", last?.let { "${"%.1f".format(Locale.US, it.tempC)}°" } ?: "—", Modifier.weight(1f))
                Stat("فشار حرارتی", thermalLabel(st.thermal), Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { if (st.running) stopMon(c) else startMon(c) },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = CYAN, contentColor = BG)
                ) { Text(if (st.running) "توقف پایش" else "شروع پایش") }
                OutlinedButton(
                    onClick = { Hub.scanNow(c) }, enabled = !st.scanning, modifier = Modifier.weight(1f)
                ) { Text(if (st.scanning) "در حال اسکن…" else "اسکن اکنون") }
            }
        }
        if (!st.usageAccess) item {
            Panel {
                Text("تحلیل رفتاری غیرفعال است", color = AMBER, fontWeight = FontWeight.Bold)
                Text("برای مقایسهٔ مصرف شبکهٔ هر برنامه با الگوی عادی آن، دسترسی Usage Access را فعال کنید. تا آن زمان فقط تحلیل ایستا (مجوزها/منبع نصب) انجام می‌شود.",
                    color = MUTED, fontSize = 12.sp)
                OutlinedButton(onClick = { openUsageAccess(c) }) { Text("فعال‌سازی دسترسی") }
            }
        }
        item {
            Panel {
                Text("مصرف RAM (زنده)", color = MUTED, fontSize = 12.sp)
                LineChart(st.samples.map { it.ramPct }, 0f, 100f, CYAN, Modifier.fillMaxWidth().height(80.dp))
            }
        }
        item {
            Panel {
                Text("دمای باتری (°C)", color = MUTED, fontSize = 12.sp)
                LineChart(st.samples.map { it.tempC }, 20f, 50f, AMBER, Modifier.fillMaxWidth().height(80.dp))
            }
        }
        item { Text("مهم‌ترین موارد", color = TEXT, fontWeight = FontWeight.Bold) }
        if (risky.isEmpty()) item {
            Panel { Text(if (st.lastScan == 0L) "هنوز اسکنی انجام نشده." else "مورد مشکوکی پیدا نشد ✓", color = MUTED) }
        }
        items(risky) { AppCard(it) }
    }
}

// ---------- apps ----------

@Composable
fun AppCard(a: AppRisk) {
    val c = LocalContext.current
    var open by remember { mutableStateOf(false) }
    Panel(Modifier.clickable { open = !open }) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(a.label, color = TEXT, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(a.pkg, color = MUTED, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(
                Modifier.clip(RoundedCornerShape(50)).background(a.level.color().copy(alpha = 0.18f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) { Text("${a.level.fa} · ${a.score}", color = a.level.color(), fontSize = 12.sp) }
        }
        AnimatedVisibility(open) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (a.reasons.isEmpty()) Text("مورد قابل‌توجهی پیدا نشد.", color = MUTED, fontSize = 12.sp)
                a.reasons.forEach { Text("• $it", color = TEXT, fontSize = 12.sp) }
                Text(
                    "ارسال ${"%.1f".format(Locale.US, a.txMb)} MB · دریافت ${"%.1f".format(Locale.US, a.rxMb)} MB · پیش‌زمینه ${a.fgMin} دقیقه (۱ ساعت اخیر)",
                    color = MUTED, fontSize = 11.sp
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton({ openAppSettings(c, a.pkg) }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("توقف اجباری", fontSize = 11.sp) }
                    OutlinedButton({ uninstallApp(c, a.pkg) }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) { Text("حذف", fontSize = 11.sp) }
                    OutlinedButton({ Hub.toggleTrust(c, a.pkg) }, Modifier.weight(1f), contentPadding = PaddingValues(4.dp)) {
                        Text(if (a.trusted) "لغو اعتماد" else "اعتماد", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun AppsScreen(st: UiState) {
    var onlyRisky by remember { mutableStateOf(true) }
    val list = if (onlyRisky) st.apps.filter { it.level != Level.SAFE } else st.apps
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("برنامه‌های نصب‌شده (${st.apps.size})", color = TEXT, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                FilterChip(selected = onlyRisky, onClick = { onlyRisky = !onlyRisky }, label = { Text("فقط مشکوک‌ها") })
            }
        }
        if (list.isEmpty()) item { Panel { Text("موردی برای نمایش نیست.", color = MUTED) } }
        items(list, key = { it.pkg }) { AppCard(it) }
    }
}

// ---------- alerts ----------

@Composable
fun AlertsScreen(st: UiState) {
    val fmt = remember { SimpleDateFormat("yyyy/MM/dd  HH:mm", Locale.getDefault()) }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("تاریخچهٔ هشدارها", color = TEXT, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (st.events.isNotEmpty()) TextButton({ Hub.clearEvents() }) { Text("پاک‌سازی") }
            }
        }
        if (st.events.isEmpty()) item { Panel { Text("هنوز هشداری ثبت نشده است.", color = MUTED) } }
        items(st.events) { e ->
            Panel {
                Row {
                    Text(e.label, color = TEXT, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("${e.score}", color = if (e.score >= 70) RED else AMBER, fontWeight = FontWeight.Bold)
                }
                Text(fmt.format(Date(e.time)), color = MUTED, fontSize = 11.sp)
                Text(e.reason, color = TEXT, fontSize = 12.sp)
            }
        }
    }
}

// ---------- settings ----------

@Composable
fun PermRow(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, color = TEXT)
                Text(if (ok) "فعال ✓" else "غیرفعال", color = if (ok) GREEN else AMBER, fontSize = 12.sp)
            }
            if (!ok) OutlinedButton(onClick) { Text(action) }
        }
    }
}

@Composable
fun SettingsScreen(st: UiState) {
    val c: Context = LocalContext.current
    val notif = NotificationManagerCompat.from(c).areNotificationsEnabled()
    val battery = c.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(c.packageName)
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("تنظیمات و مجوزها", color = TEXT, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        item { PermRow("دسترسی Usage (تحلیل مصرف شبکه و پیش‌زمینه)", st.usageAccess, "فعال‌سازی") { openUsageAccess(c) } }
        item { PermRow("معافیت از بهینه‌سازی باتری (پایداری سرویس)", battery, "درخواست") { openBatterySettings(c) } }
        item { PermRow("اعلان‌ها", notif, "تنظیمات") { openAppSettings(c, c.packageName) } }
        item {
            Panel {
                Text("دربارهٔ موتور تشخیص", color = CYAN, fontWeight = FontWeight.Bold)
                Text("• تحلیل ایستا: منبع نصب، مجوزهای خطرناک، Accessibility و Device Admin", color = MUTED, fontSize = 12.sp)
                Text("• تحلیل پویا: حجم ارسال هر برنامه در ساعت اخیر در برابر تاریخچهٔ ۷ روزهٔ خود همان برنامه (z-score)", color = MUTED, fontSize = 12.sp)
                Text("• همهٔ داده‌ها فقط روی همین دستگاه می‌مانند و هیچ چیزی ارسال نمی‌شود.", color = MUTED, fontSize = 12.sp)
                Text("• اندروید به برنامه‌های عادی اجازهٔ بستن یا قرنطینهٔ برنامهٔ دیگر را نمی‌دهد؛ این برنامه شما را به صفحهٔ «توقف اجباری/حذف» می‌برد.", color = MUTED, fontSize = 12.sp)
            }
        }
        item { Text("نسخه ۲٫۰ · ${st.apps.count { it.trusted }} برنامهٔ مورد اعتماد", color = MUTED, fontSize = 11.sp) }
    }
}
