package com.example.aibs

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** Tiny persistent store (SharedPreferences). Everything stays on the device. */
object Store {
    private lateinit var p: SharedPreferences

    fun init(c: Context) {
        if (!::p.isInitialized) p = c.applicationContext.getSharedPreferences("aibs", Context.MODE_PRIVATE)
    }

    var serviceEnabled: Boolean
        get() = p.getBoolean("svc", false)
        set(v) { p.edit().putBoolean("svc", v).apply() }

    var whitelist: Set<String>
        get() = p.getStringSet("wl", emptySet())!!.toSet()
        set(v) { p.edit().putStringSet("wl", v).apply() }

    fun lastAlert(pkg: String): Long = p.getLong("la_$pkg", 0L)
    fun setLastAlert(pkg: String, t: Long) { p.edit().putLong("la_$pkg", t).apply() }

    fun events(): List<ThreatEvent> = try {
        val arr = JSONArray(p.getString("ev", "[]"))
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            ThreatEvent(o.getLong("t"), o.getString("p"), o.getString("l"), o.getInt("s"), o.getString("r"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun addEvent(e: ThreatEvent) {
        val all = (listOf(e) + events()).take(100)
        val arr = JSONArray()
        all.forEach {
            arr.put(JSONObject().put("t", it.time).put("p", it.pkg).put("l", it.label).put("s", it.score).put("r", it.reason))
        }
        p.edit().putString("ev", arr.toString()).apply()
    }

    fun clearEvents() { p.edit().putString("ev", "[]").apply() }
}
