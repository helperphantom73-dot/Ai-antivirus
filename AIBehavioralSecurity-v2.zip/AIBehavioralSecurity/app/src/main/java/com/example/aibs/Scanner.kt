package com.example.aibs

import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.ln
import kotlin.math.sqrt

/**
 * Hybrid detector:
 *  1) Static risk  : install source, dangerous permissions, accessibility / device-admin.
 *  2) Dynamic risk : each app's upload volume in the last hour vs. its OWN 7-day history
 *                    (z-score on log-bytes), plus background / upload-heavy patterns.
 * Dynamic analysis needs "Usage Access"; without it only static analysis runs.
 */
object Scanner {
    private const val HOUR = 3_600_000L
    private const val MB = 1_048_576.0

    private val TRUSTED_STORES = setOf(
        "com.android.vending", "com.farsitel.bazaar", "ir.mservices.market",
        "com.sec.android.app.samsungapps", "com.huawei.appmarket", "com.amazon.venezia"
    )
    private val SENSITIVE = setOf(
        "android.permission.RECORD_AUDIO", "android.permission.CAMERA",
        "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_CONTACTS",
        "android.permission.READ_SMS", "android.permission.READ_CALL_LOG"
    )
    private val SMS = setOf(
        "android.permission.READ_SMS", "android.permission.RECEIVE_SMS", "android.permission.SEND_SMS"
    )

    private class Acc {
        var curTx = 0.0
        var curRx = 0.0
        var s1 = 0.0 // sum of hourly ln(1+bytes/h)
        var s2 = 0.0 // sum of squares
    }

    suspend fun scan(c: Context): List<AppRisk> = withContext(Dispatchers.Default) {
        val pm = c.packageManager
        val now = System.currentTimeMillis()
        val usage = Metrics.hasUsageAccess(c)
        val net = if (usage) netStats(c, now) else emptyMap()
        val fg = if (usage) foreground(c, now) else emptyMap()
        val wl = Store.whitelist

        val out = ArrayList<AppRisk>()
        for (ai in installedApps(pm)) {
            if (ai.packageName == c.packageName) continue
            val isSystem = (ai.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0
            if (isSystem) continue
            try {
                out += analyze(pm, ai, now, net, fg, wl)
            } catch (e: Exception) {
                // skip broken package
            }
        }
        out.sortedByDescending { if (it.trusted) -1 else it.score }
    }

    private fun analyze(
        pm: PackageManager, ai: ApplicationInfo, now: Long,
        net: Map<Int, Acc>, fg: Map<String, Long>, wl: Set<String>
    ): AppRisk {
        val pkg = ai.packageName
        val pi = pkgInfo(pm, pkg)
        val reasons = ArrayList<String>()
        var stat = 0
        val perms = pi?.requestedPermissions?.toSet() ?: emptySet()
        val inst = installer(pm, pkg)

        if (inst == null || inst !in TRUSTED_STORES) {
            stat += 12; reasons += "نصب‌شده خارج از فروشگاه‌های شناخته‌شده"
        }
        if ("android.permission.SYSTEM_ALERT_WINDOW" in perms) {
            stat += 8; reasons += "اجازهٔ نمایش روی سایر برنامه‌ها (ریسک Overlay)"
        }
        if ("android.permission.REQUEST_INSTALL_PACKAGES" in perms) {
            stat += 6; reasons += "امکان درخواست نصب برنامه‌های دیگر"
        }
        if (perms.any { it in SMS }) {
            stat += 10; reasons += "دسترسی به پیامک"
        }
        if ("android.permission.READ_CALL_LOG" in perms) {
            stat += 5; reasons += "دسترسی به تاریخچهٔ تماس"
        }
        if ("android.permission.MANAGE_EXTERNAL_STORAGE" in perms) {
            stat += 5; reasons += "دسترسی کامل به فایل‌ها"
        }
        if (pi?.services?.any { it.permission == "android.permission.BIND_ACCESSIBILITY_SERVICE" } == true) {
            stat += 15; reasons += "سرویس دسترسی‌پذیری (Accessibility) فعال‌شدنی"
        }
        if (pi?.receivers?.any { it.permission == "android.permission.BIND_DEVICE_ADMIN" } == true) {
            stat += 10; reasons += "درخواست مدیر دستگاه (Device Admin)"
        }
        if (perms.count { it in SENSITIVE } >= 4) {
            stat += 6; reasons += "ترکیب چند مجوز بسیار حساس"
        }
        stat = stat.coerceAtMost(45)

        var dyn = 0
        var txMb = 0.0
        var rxMb = 0.0
        val fgMin = ((fg[pkg] ?: 0L) / 60_000L).toInt()
        val a = net[ai.uid]
        if (a != null) {
            txMb = a.curTx / MB
            rxMb = a.curRx / MB
            val histHours = minOf(167.0, (now - (pi?.firstInstallTime ?: 0L)).toDouble() / HOUR)
            if (histHours >= 24 && txMb >= 2.0) {
                val mean = a.s1 / histHours
                val variance = (a.s2 / histHours - mean * mean).coerceAtLeast(0.0)
                val z = (ln(1.0 + a.curTx) - mean) / (sqrt(variance) + 0.5)
                if (z > 2.0) {
                    dyn += ((z - 2.0) * 10).toInt().coerceAtMost(40)
                    reasons += "ارسال ${f1(txMb)} مگابایت در ساعت اخیر؛ بسیار بالاتر از الگوی عادی همین برنامه (z=${f1(z)})"
                }
            }
            if (fgMin == 0 && txMb >= 5.0) {
                dyn += 15; reasons += "ارسال ${f1(txMb)} مگابایت در پس‌زمینه بدون استفادهٔ فعال کاربر"
            }
            if (txMb >= 10.0 && txMb > 3 * rxMb) {
                dyn += 10; reasons += "حجم ارسال چند برابر دریافت (الگوی احتمالی نشت داده)"
            }
        }
        dyn = dyn.coerceAtMost(60)

        val total = (stat + dyn).coerceAtMost(100)
        val trusted = pkg in wl
        val level = when {
            trusted -> Level.SAFE
            total >= 70 -> Level.HIGH
            total >= 40 -> Level.MEDIUM
            total >= 20 -> Level.WATCH
            else -> Level.SAFE
        }
        val label = try { pm.getApplicationLabel(ai).toString() } catch (e: Exception) { pkg }
        return AppRisk(pkg, label, total, dyn, level, reasons, txMb, rxMb, fgMin, trusted)
    }

    @Suppress("DEPRECATION")
    private fun netStats(c: Context, now: Long): Map<Int, Acc> {
        val nsm = c.getSystemService(NetworkStatsManager::class.java)
        val acc = HashMap<Int, Acc>()
        val cutoff = now - HOUR
        for (type in intArrayOf(ConnectivityManager.TYPE_WIFI, ConnectivityManager.TYPE_MOBILE)) {
            try {
                val st = nsm.querySummary(type, null, now - 7 * 24 * HOUR, now)
                val b = NetworkStats.Bucket()
                while (st.hasNextBucket()) {
                    st.getNextBucket(b)
                    val s = b.startTimeStamp
                    val e = b.endTimeStamp
                    val dur = (e - s).coerceAtLeast(1L).toDouble()
                    val a = acc.getOrPut(b.uid) { Acc() }
                    if (e > cutoff) {
                        val ov = (e - maxOf(s, cutoff)).toDouble() / dur
                        a.curTx += b.txBytes * ov
                        a.curRx += b.rxBytes * ov
                    }
                    if (s < cutoff) {
                        val histDur = (minOf(e, cutoff) - s).toDouble()
                        val hrs = histDur / HOUR
                        if (hrs > 0) {
                            val rate = b.txBytes * (histDur / dur) / hrs
                            val x = ln(1.0 + rate)
                            a.s1 += hrs * x
                            a.s2 += hrs * x * x
                        }
                    }
                }
                st.close()
            } catch (e: Exception) {
                // network type unavailable on this device
            }
        }
        return acc
    }

    @Suppress("DEPRECATION")
    private fun foreground(c: Context, now: Long): Map<String, Long> {
        val usm = c.getSystemService(UsageStatsManager::class.java)
        val ev = usm.queryEvents(now - HOUR, now)
        val e = UsageEvents.Event()
        val open = HashMap<String, Long>()
        val total = HashMap<String, Long>()
        while (ev.hasNextEvent()) {
            ev.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> open[e.packageName] = e.timeStamp
                UsageEvents.Event.MOVE_TO_BACKGROUND -> {
                    val st = open.remove(e.packageName)
                    if (st != null) total[e.packageName] = (total[e.packageName] ?: 0L) + (e.timeStamp - st)
                }
            }
        }
        for ((p, st) in open) total[p] = (total[p] ?: 0L) + (now - st)
        return total
    }

    @Suppress("DEPRECATION")
    private fun installedApps(pm: PackageManager): List<ApplicationInfo> =
        if (Build.VERSION.SDK_INT >= 33)
            pm.getInstalledApplications(PackageManager.ApplicationInfoFlags.of(0L))
        else pm.getInstalledApplications(0)

    @Suppress("DEPRECATION")
    private fun pkgInfo(pm: PackageManager, pkg: String): PackageInfo? = try {
        val f = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS
        if (Build.VERSION.SDK_INT >= 33) pm.getPackageInfo(pkg, PackageManager.PackageInfoFlags.of(f.toLong()))
        else pm.getPackageInfo(pkg, f)
    } catch (e: Exception) {
        null
    }

    @Suppress("DEPRECATION")
    private fun installer(pm: PackageManager, pkg: String): String? = try {
        if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(pkg).installingPackageName
        else pm.getInstallerPackageName(pkg)
    } catch (e: Exception) {
        null
    }

    private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)
}
