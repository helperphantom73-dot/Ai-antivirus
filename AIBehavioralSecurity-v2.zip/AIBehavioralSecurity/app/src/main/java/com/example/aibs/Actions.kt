package com.example.aibs

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

fun startMon(c: Context) { tryStartService(c) }

fun stopMon(c: Context) {
    Store.serviceEnabled = false
    c.stopService(Intent(c, SecurityService::class.java))
    Hub.setRunning(false)
}

private fun safeStart(c: Context, i: Intent) = try {
    c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
} catch (e: Exception) { }

fun openAppSettings(c: Context, pkg: String) =
    safeStart(c, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))

fun uninstallApp(c: Context, pkg: String) =
    safeStart(c, Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")))

fun openUsageAccess(c: Context) = safeStart(c, Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

fun openBatterySettings(c: Context) =
    safeStart(c, Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${c.packageName}")))
