package com.example.aibs

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

fun tryStartService(c: Context): Boolean = try {
    ContextCompat.startForegroundService(c, Intent(c, SecurityService::class.java))
    true
} catch (e: Exception) {
    false // Android 12+ may forbid starting a foreground service from the background
}

class WatchdogWorker(c: Context, p: WorkerParameters) : CoroutineWorker(c, p) {
    override suspend fun doWork(): Result {
        Store.init(applicationContext)
        if (Store.serviceEnabled && !Hub.state.value.running) {
            if (!tryStartService(applicationContext)) Alerts.notifyStopped(applicationContext)
        }
        return Result.success()
    }
}

object Watchdog {
    fun schedule(c: Context) {
        val req = PeriodicWorkRequestBuilder<WatchdogWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("watchdog", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_BOOT_COMPLETED) return
        Store.init(c)
        if (Store.serviceEnabled) tryStartService(c)
        Watchdog.schedule(c)
    }
}
