package com.example.aibs

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Foreground monitor with ADAPTIVE sampling:
 *  screen on  -> sample every 5 s, full scan every 3 min
 *  screen off -> sample every 60 s, full scan every 10 min
 */
class SecurityService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Alerts.channels(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = Alerts.serviceNotif(this, "در حال راه‌اندازی…")
        if (Build.VERSION.SDK_INT >= 34)
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(NOTIF_ID, n)

        Store.serviceEnabled = true
        Hub.setRunning(true)
        if (job == null) job = scope.launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        var lastScan = 0L
        var lastText = ""
        while (true) {
            val interactive = Metrics.interactive(this)
            Hub.pushSample(this)

            val now = System.currentTimeMillis()
            val every = if (interactive) 3 * 60_000L else 10 * 60_000L
            if (now - lastScan >= every) {
                Hub.runScan(this)
                lastScan = now
            }

            val s = Hub.state.value
            val text = "امنیت: ${s.deviceScore}% · ${scoreLabel(s.deviceScore)}"
            if (text != lastText) {
                lastText = text
                getSystemService(android.app.NotificationManager::class.java)
                    .notify(NOTIF_ID, Alerts.serviceNotif(this, text))
            }
            delay(if (interactive) 5_000L else 60_000L)
        }
    }

    override fun onDestroy() {
        scope.cancel()
        Hub.setRunning(false)
        super.onDestroy()
    }

    companion object {
        const val NOTIF_ID = 7
    }
}
