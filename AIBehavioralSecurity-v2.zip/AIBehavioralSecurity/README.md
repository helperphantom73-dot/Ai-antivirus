# AI Behavioral Security v2

## ساخت (Build)
1. پروژه را در Android Studio (Ladybug یا جدیدتر، JDK 17) باز کنید و Sync بزنید.
2. Build > Build APK(s)  یا:  `gradle wrapper --gradle-version 8.9`  سپس  `./gradlew assembleDebug`
3. خروجی: app/build/outputs/apk/debug/app-debug.apk

## بعد از نصب
- دسترسی «Usage Access» را از تب تنظیمات فعال کنید (بدون آن فقط تحلیل ایستا کار می‌کند).
- معافیت از بهینه‌سازی باتری را بدهید تا سرویس پایدارتر بماند.

## معماری
UI (Compose) <- Hub (StateFlow) <- SecurityService / Scanner / Metrics
Scanner = تحلیل ایستا (مجوزها، منبع نصب) + تحلیل پویا (ارسال شبکهٔ ساعت اخیر در برابر baseline ۷ روزهٔ همان برنامه)
Watchdog = WorkManager هر ۱۵ دقیقه + BootReceiver

## محدودیت‌ها
- /proc/stat و /proc/net/tcp برای برنامه‌های عادی بسته است؛ CPU کل سیستم نمایش داده نمی‌شود (فشار حرارتی جایگزین است).
- kill/quarantine برنامهٔ دیگر بدون Root/Device Owner ممکن نیست؛ برنامه کاربر را به صفحهٔ Force Stop/Uninstall می‌برد.
- این کد روی این سیستم کامپایل نشده؛ اگر Build خطا داد، متن خطا را بفرستید تا رفع کنم.
